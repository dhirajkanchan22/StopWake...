package com.example.stopwake.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.stopwake.R
import com.example.stopwake.data.local.LocationAlarmEntity
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MapStyleOptions
import com.google.maps.android.compose.*
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddLocationAlarmScreen(
    onSaveAlarm: (LocationAlarmEntity) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current

    var selectedLatLng by remember { mutableStateOf(LatLng(19.0760, 72.8777)) }
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(selectedLatLng, 12.5f)
    }

    var destinationName by remember { mutableStateOf("") }
    var presetTitle by remember { mutableStateOf("") }
    var radiusMeters by remember { mutableFloatStateOf(1000f) }
    var isFavoritePreset by remember { mutableStateOf(true) }
    var headphoneModeOnly by remember { mutableStateOf(false) }

    val mapProperties = remember {
        MapProperties(
            mapStyleOptions = MapStyleOptions.loadRawResourceStyle(
                context,
                R.raw.map_style_neutral
            )
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Set Destination Stop") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
            ) {
                GoogleMap(
                    modifier = Modifier.fillMaxSize(),
                    cameraPositionState = cameraPositionState,
                    properties = mapProperties,
                    uiSettings = MapUiSettings(zoomControlsEnabled = false),
                    onMapClick = { latLng -> selectedLatLng = latLng }
                ) {
                    Marker(
                        state = MarkerState(position = selectedLatLng),
                        title = destinationName.ifBlank { "Wake Stop" }
                    )
                    Circle(
                        center = selectedLatLng,
                        radius = radiusMeters.toDouble(),
                        fillColor = Color(0x332C2C2E),
                        strokeColor = Color(0xFF2C2C2E),
                        strokeWidth = 3f
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Tap anywhere on the map to place your stop pin.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = destinationName,
                    onValueChange = { destinationName = it },
                    label = { Text("Destination / Station Name") },
                    placeholder = { Text("e.g., Andheri Station, Office Stop") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = presetTitle,
                    onValueChange = { presetTitle = it },
                    label = { Text("Commute Label (Optional)") },
                    placeholder = { Text("e.g., Morning Train, Evening Bus") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Wake-Up Trigger Radius", style = MaterialTheme.typography.labelLarge)
                            Text(
                                text = if (radiusMeters >= 1000f) {
                                    "${(radiusMeters / 100f).roundToInt() / 10f} km before"
                                } else {
                                    "${radiusMeters.roundToInt()} m before"
                                },
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Slider(
                            value = radiusMeters,
                            onValueChange = { radiusMeters = (it / 100f).roundToInt() * 100f },
                            valueRange = 500f..5000f,
                            steps = 44
                        )
                        Text(
                            text = "Tip: Use 1.5 km – 3 km for fast trains and 500 m – 1 km for city buses.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Pin to Daily Commute Presets", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "One-tap activation from the top of your dashboard",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = isFavoritePreset, onCheckedChange = { isFavoritePreset = it })
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Headphone-First Alarm", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "Rings in earphones first; speaker fallback after 30s",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = headphoneModeOnly, onCheckedChange = { headphoneModeOnly = it })
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = {
                        onSaveAlarm(
                            LocationAlarmEntity(
                                title = presetTitle.trim(),
                                destinationName = destinationName.ifBlank { "Selected Stop" }.trim(),
                                latitude = selectedLatLng.latitude,
                                longitude = selectedLatLng.longitude,
                                triggerRadiusMeters = radiusMeters.roundToInt(),
                                isEnabled = true,
                                isFavoritePreset = isFavoritePreset,
                                headphoneModeOnly = headphoneModeOnly
                            )
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    shape = MaterialTheme.shapes.medium
                ) {
                    Text("Save & Activate Alarm", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}
