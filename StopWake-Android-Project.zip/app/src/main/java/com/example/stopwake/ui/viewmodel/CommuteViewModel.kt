package com.example.stopwake.ui.viewmodel

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.stopwake.data.local.LocationAlarmEntity
import com.example.stopwake.data.local.TimeAlarmEntity
import com.example.stopwake.data.repository.AlarmRepository
import com.example.stopwake.service.ExactAlarmScheduler
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class LiveCommuteStatus(
    val isTracking: Boolean = false,
    val activeAlarmId: Long? = null,
    val destinationName: String = "",
    val distanceRemainingMeters: Float? = null,
    val triggerRadiusMeters: Int = 1000
)

object ActiveTripStateHolder {
    private val _status = MutableStateFlow(LiveCommuteStatus())
    val status: StateFlow<LiveCommuteStatus> = _status.asStateFlow()

    fun updateStatus(newStatus: LiveCommuteStatus) {
        _status.value = newStatus
    }

    fun clear() {
        _status.value = LiveCommuteStatus()
    }
}

class CommuteViewModel(
    private val repository: AlarmRepository
) : ViewModel() {

    val locationAlarms: StateFlow<List<LocationAlarmEntity>> = repository.allLocationAlarms
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoritePresets: StateFlow<List<LocationAlarmEntity>> = repository.favoritePresets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val timeAlarms: StateFlow<List<TimeAlarmEntity>> = repository.allTimeAlarms
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val liveCommuteStatus: StateFlow<LiveCommuteStatus> = ActiveTripStateHolder.status

    fun saveAndActivateLocationAlarm(
        context: Context,
        alarm: LocationAlarmEntity,
        onSaved: () -> Unit
    ) {
        viewModelScope.launch {
            val id = repository.saveLocationAlarm(alarm)
            if (alarm.isEnabled) {
                startTrackingService(context, alarm.copy(id = id))
            }
            onSaved()
        }
    }

    fun toggleLocationAlarm(context: Context, alarm: LocationAlarmEntity, enabled: Boolean) {
        viewModelScope.launch {
            repository.toggleLocationAlarm(alarm.id, enabled)
            if (enabled) {
                startTrackingService(context, alarm.copy(isEnabled = true))
            } else {
                val remaining = repository.getActiveLocationAlarmsSnapshot().filter { it.id != alarm.id }
                if (remaining.isEmpty()) stopTrackingService(context)
            }
        }
    }

    fun toggleFavoritePreset(alarm: LocationAlarmEntity) {
        viewModelScope.launch {
            repository.toggleFavoritePreset(alarm.id, !alarm.isFavoritePreset)
        }
    }

    fun deleteLocationAlarm(context: Context, alarm: LocationAlarmEntity) {
        viewModelScope.launch {
            repository.deleteLocationAlarm(alarm)
            if (repository.getActiveLocationAlarmsSnapshot().isEmpty()) {
                stopTrackingService(context)
            }
        }
    }

    fun saveTimeAlarm(context: Context, hour: Int, minute: Int, label: String, headphoneMode: Boolean) {
        viewModelScope.launch {
            val entity = TimeAlarmEntity(
                hour = hour,
                minute = minute,
                label = label.ifBlank { "Wake Up" },
                isEnabled = true,
                headphoneModeOnly = headphoneMode
            )
            val id = repository.saveTimeAlarm(entity)
            ExactAlarmScheduler.scheduleTimeAlarm(context, entity.copy(id = id))
        }
    }

    fun toggleTimeAlarm(context: Context, alarm: TimeAlarmEntity, enabled: Boolean) {
        viewModelScope.launch {
            repository.toggleTimeAlarm(alarm.id, enabled)
            if (enabled) {
                ExactAlarmScheduler.scheduleTimeAlarm(context, alarm.copy(isEnabled = true))
            } else {
                ExactAlarmScheduler.cancelTimeAlarm(context, alarm.id)
            }
        }
    }

    fun deleteTimeAlarm(context: Context, alarm: TimeAlarmEntity) {
        viewModelScope.launch {
            ExactAlarmScheduler.cancelTimeAlarm(context, alarm.id)
            repository.deleteTimeAlarm(alarm)
        }
    }

    fun stopAllActiveTracking(context: Context) {
        viewModelScope.launch {
            repository.getActiveLocationAlarmsSnapshot().forEach {
                repository.toggleLocationAlarm(it.id, false)
            }
            stopTrackingService(context)
        }
    }

    private fun startTrackingService(context: Context, alarm: LocationAlarmEntity) {
        ActiveTripStateHolder.updateStatus(
            LiveCommuteStatus(
                isTracking = true,
                activeAlarmId = alarm.id,
                destinationName = alarm.destinationName,
                distanceRemainingMeters = null,
                triggerRadiusMeters = alarm.triggerRadiusMeters
            )
        )
        val intent = Intent().apply {
            setClassName(context.packageName, "com.example.stopwake.service.LocationTrackingService")
            action = "ACTION_START_TRACKING"
            putExtra("ALARM_ID", alarm.id)
        }
        ContextCompat.startForegroundService(context, intent)
    }

    private fun stopTrackingService(context: Context) {
        ActiveTripStateHolder.clear()
        val intent = Intent().apply {
            setClassName(context.packageName, "com.example.stopwake.service.LocationTrackingService")
            action = "ACTION_STOP_TRACKING"
        }
        context.startService(intent)
    }
}

class CommuteViewModelFactory(
    private val repository: AlarmRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return CommuteViewModel(repository) as T
    }
}
