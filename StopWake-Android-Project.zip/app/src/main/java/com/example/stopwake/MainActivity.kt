package com.example.stopwake

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.stopwake.data.local.StopWakeDatabase
import com.example.stopwake.data.repository.AlarmRepository
import com.example.stopwake.ui.screens.AddLocationAlarmScreen
import com.example.stopwake.ui.screens.HomeScreen
import com.example.stopwake.ui.screens.PermissionGate
import com.example.stopwake.ui.theme.StopWakeTheme
import com.example.stopwake.ui.viewmodel.CommuteViewModel
import com.example.stopwake.ui.viewmodel.CommuteViewModelFactory

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val database = StopWakeDatabase.getInstance(applicationContext)
        val repository = AlarmRepository(database.alarmDao())

        setContent {
            StopWakeTheme {
                PermissionGate {
                    val navController = rememberNavController()
                    val commuteViewModel: CommuteViewModel = viewModel(
                        factory = CommuteViewModelFactory(repository)
                    )

                    NavHost(
                        navController = navController,
                        startDestination = "home"
                    ) {
                        composable("home") {
                            HomeScreen(
                                viewModel = commuteViewModel,
                                onNavigateToMapPicker = {
                                    navController.navigate("add_location_alarm")
                                }
                            )
                        }
                        composable("add_location_alarm") {
                            AddLocationAlarmScreen(
                                onSaveAlarm = { newAlarm ->
                                    commuteViewModel.saveAndActivateLocationAlarm(
                                        context = applicationContext,
                                        alarm = newAlarm,
                                        onSaved = { navController.popBackStack() }
                                    )
                                },
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
