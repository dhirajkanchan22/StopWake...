package com.example.stopwake.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "time_alarms")
data class TimeAlarmEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val hour: Int,
    val minute: Int,
    val label: String = "",
    val isEnabled: Boolean = true,
    val recurringDays: Set<Int> = emptySet(),
    val vibrate: Boolean = true,
    val headphoneModeOnly: Boolean = false,
    val ringtoneUri: String? = null
)
