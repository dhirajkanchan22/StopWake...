package com.example.stopwake.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface AlarmDao {

    @Query("SELECT * FROM location_alarms ORDER BY isFavoritePreset DESC, isEnabled DESC, createdAt DESC")
    fun observeAllLocationAlarms(): Flow<List<LocationAlarmEntity>>

    @Query("SELECT * FROM location_alarms WHERE isEnabled = 1")
    fun observeActiveLocationAlarms(): Flow<List<LocationAlarmEntity>>

    @Query("SELECT * FROM location_alarms WHERE isEnabled = 1")
    suspend fun getActiveLocationAlarmsSnapshot(): List<LocationAlarmEntity>

    @Query("SELECT * FROM location_alarms WHERE isFavoritePreset = 1 ORDER BY title ASC")
    fun observeFavoritePresets(): Flow<List<LocationAlarmEntity>>

    @Query("SELECT * FROM location_alarms WHERE id = :id LIMIT 1")
    suspend fun getLocationAlarmById(id: Long): LocationAlarmEntity?

    @Upsert
    suspend fun upsertLocationAlarm(alarm: LocationAlarmEntity): Long

    @Query("UPDATE location_alarms SET isEnabled = :enabled WHERE id = :id")
    suspend fun setLocationAlarmEnabled(id: Long, enabled: Boolean)

    @Query("UPDATE location_alarms SET isFavoritePreset = :isFavorite WHERE id = :id")
    suspend fun setLocationAlarmFavorite(id: Long, isFavorite: Boolean)

    @Delete
    suspend fun deleteLocationAlarm(alarm: LocationAlarmEntity)

    @Query("SELECT * FROM time_alarms ORDER BY hour ASC, minute ASC")
    fun observeAllTimeAlarms(): Flow<List<TimeAlarmEntity>>

    @Query("SELECT * FROM time_alarms WHERE isEnabled = 1")
    suspend fun getActiveTimeAlarmsSnapshot(): List<TimeAlarmEntity>

    @Query("SELECT * FROM time_alarms WHERE id = :id LIMIT 1")
    suspend fun getTimeAlarmById(id: Long): TimeAlarmEntity?

    @Upsert
    suspend fun upsertTimeAlarm(alarm: TimeAlarmEntity): Long

    @Query("UPDATE time_alarms SET isEnabled = :enabled WHERE id = :id")
    suspend fun setTimeAlarmEnabled(id: Long, enabled: Boolean)

    @Delete
    suspend fun deleteTimeAlarm(alarm: TimeAlarmEntity)
}
