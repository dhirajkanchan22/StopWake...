package com.example.stopwake.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.stopwake.ui.screens.AlarmRingingActivity
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent

class AlarmTriggerReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            "ACTION_GEOFENCE_TRANSITION" -> {
                val geofencingEvent = GeofencingEvent.fromIntent(intent) ?: return
                if (geofencingEvent.hasError()) return

                if (geofencingEvent.geofenceTransition == Geofence.GEOFENCE_TRANSITION_ENTER) {
                    AlarmAudioController.startAlarm(context, vibrate = true, headphoneModeOnly = false)
                    val ringIntent = Intent(context, AlarmRingingActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                        putExtra("DESTINATION_NAME", "Your Commute Stop")
                        putExtra("DISTANCE_METERS", 500)
                    }
                    context.startActivity(ringIntent)
                }
            }

            "ACTION_TIME_ALARM_TRIGGER" -> {
                val label = intent.getStringExtra("ALARM_LABEL") ?: "Clock Alarm"
                val headphoneOnly = intent.getBooleanExtra("HEADPHONE_MODE", false)

                AlarmAudioController.startAlarm(
                    context = context,
                    vibrate = true,
                    headphoneModeOnly = headphoneOnly
                )

                val ringIntent = Intent(context, AlarmRingingActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra("DESTINATION_NAME", label)
                    putExtra("DISTANCE_METERS", 0)
                }
                context.startActivity(ringIntent)
            }
        }
    }
}
