package com.example.stopwake.ui.theme

import androidx.compose.ui.graphics.Color

val LightBackground = Color(0xFFF7F6F2)
val LightSurface = Color(0xFFEBE9E4)
val LightSurfaceElevated = Color(0xFFE0DDD6)
val LightPrimary = Color(0xFF2C2C2E)
val LightOnPrimary = Color(0xFFF7F6F2)
val LightSecondary = Color(0xFF525256)
val LightTextPrimary = Color(0xFF1C1C1E)
val LightTextSecondary = Color(0xFF6E6E73)
val LightOutline = Color(0xFFD1CFC9)

val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E20)
val DarkSurfaceElevated = Color(0xFF2A2A2D)
val DarkPrimary = Color(0xFFE5E5EA)
val DarkOnPrimary = Color(0xFF121212)
val DarkSecondary = Color(0xFFA1A1AA)
val DarkTextPrimary = Color(0xFFE5E5EA)
val DarkTextSecondary = Color(0xFF8E8E93)
val DarkOutline = Color(0xFF343438)

val StatusActiveSage = Color(0xFF5E7A68)
val StatusAlertTerracotta = Color(0xFFB85D51)
