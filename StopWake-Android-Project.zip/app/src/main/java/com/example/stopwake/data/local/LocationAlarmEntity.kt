package com.example.stopwake.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "location_alarms")
data class LocationAlarmEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val title: String,
    val destinationName: String,
    val latitude: Double,
    val longitude: Double,
    val triggerRadiusMeters: Int = 1000,
    val isEnabled: Boolean = true,
    val isFavoritePreset: Boolean = false,
    val recurringDays: Set<Int> = emptySet(),
    val autoArmStartHour: Int? = null,
    val autoArmEndHour: Int? = null,
    val vibrate: Boolean = true,
    val headphoneModeOnly: Boolean = false,
    val ringtoneUri: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
