package com.example.stopwake.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.example.stopwake.MainActivity
import com.example.stopwake.data.local.LocationAlarmEntity
import com.example.stopwake.data.local.StopWakeDatabase
import com.example.stopwake.ui.screens.AlarmRingingActivity
import com.example.stopwake.ui.viewmodel.ActiveTripStateHolder
import com.example.stopwake.ui.viewmodel.LiveCommuteStatus
import com.google.android.gms.location.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt

class LocationTrackingService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var geofencingClient: GeofencingClient
    private lateinit var notificationManager: NotificationManager

    private var activeAlarms: List<LocationAlarmEntity> = emptyList()
    private var currentPollingTier: PollingTier = PollingTier.NONE
    private var isAlarmCurrentlyRinging = false

    private enum class PollingTier(val intervalMs: Long, val minIntervalMs: Long, val priority: Int) {
        NONE(0L, 0L, Priority.PRIORITY_PASSIVE),
        FAR(45_000L, 20_000L, Priority.PRIORITY_BALANCED_POWER_ACCURACY),
        MEDIUM(15_000L, 8_000L, Priority.PRIORITY_HIGH_ACCURACY),
        APPROACH(3_000L, 1_500L, Priority.PRIORITY_HIGH_ACCURACY)
    }

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val currentLocation = result.lastLocation ?: return
            evaluateDistanceToStops(currentLocation)
        }
    }

    override fun onCreate() {
        super.onCreate()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        geofencingClient = LocationServices.getGeofencingClient(this)
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "ACTION_START_TRACKING" -> {
                startForegroundWithNotification("Tracking your commute...", "Acquiring GPS signal")
                refreshActiveAlarmsAndStartTracking()
            }
            "ACTION_STOP_TRACKING" -> {
                stopTrackingAndCleanup()
            }
        }
        return START_STICKY
    }

    private fun refreshActiveAlarmsAndStartTracking() {
        serviceScope.launch {
            val dao = StopWakeDatabase.getInstance(applicationContext).alarmDao()
            activeAlarms = dao.getActiveLocationAlarmsSnapshot()

            if (activeAlarms.isEmpty()) {
                stopTrackingAndCleanup()
                return@launch
            }

            registerBackupGeofences(activeAlarms)
            switchPollingTier(PollingTier.MEDIUM)
        }
    }

    @SuppressLint("MissingPermission")
    private fun switchPollingTier(newTier: PollingTier) {
        if (currentPollingTier == newTier || newTier == PollingTier.NONE) return
        currentPollingTier = newTier

        fusedLocationClient.removeLocationUpdates(locationCallback)

        val request = LocationRequest.Builder(newTier.priority, newTier.intervalMs)
            .setMinUpdateIntervalMillis(newTier.minIntervalMs)
            .setWaitForAccurateLocation(false)
            .build()

        fusedLocationClient.requestLocationUpdates(
            request,
            locationCallback,
            Looper.getMainLooper()
        )
    }

    private fun evaluateDistanceToStops(currentLocation: Location) {
        if (activeAlarms.isEmpty() || isAlarmCurrentlyRinging) return

        var closestAlarm: LocationAlarmEntity? = null
        var minDistanceMeters = Float.MAX_VALUE

        for (alarm in activeAlarms) {
            val results = FloatArray(1)
            Location.distanceBetween(
                currentLocation.latitude,
                currentLocation.longitude,
                alarm.latitude,
                alarm.longitude,
                results
            )
            val distance = results[0]

            if (distance < minDistanceMeters) {
                minDistanceMeters = distance
                closestAlarm = alarm
            }

            if (distance <= alarm.triggerRadiusMeters) {
                triggerDestinationAlarm(alarm, distance.roundToInt())
                return
            }
        }

        closestAlarm?.let { nearest ->
            ActiveTripStateHolder.updateStatus(
                LiveCommuteStatus(
                    isTracking = true,
                    activeAlarmId = nearest.id,
                    destinationName = nearest.destinationName,
                    distanceRemainingMeters = minDistanceMeters,
                    triggerRadiusMeters = nearest.triggerRadiusMeters
                )
            )

            val formattedDistance = if (minDistanceMeters >= 1000f) {
                String.format(Locale.US, "%.1f km to %s", minDistanceMeters / 1000f, nearest.destinationName)
            } else {
                "${minDistanceMeters.roundToInt()} m to ${nearest.destinationName}"
            }

            updatePersistentNotification(
                title = formattedDistance,
                subtitle = "Wake alert set for ${nearest.triggerRadiusMeters}m before stop"
            )

            val desiredTier = when {
                minDistanceMeters > 10_000f -> PollingTier.FAR
                minDistanceMeters > 3_000f -> PollingTier.MEDIUM
                else -> PollingTier.APPROACH
            }
            switchPollingTier(desiredTier)
        }
    }

    private fun triggerDestinationAlarm(alarm: LocationAlarmEntity, currentDistanceMeters: Int) {
        isAlarmCurrentlyRinging = true

        serviceScope.launch {
            val dao = StopWakeDatabase.getInstance(applicationContext).alarmDao()
            if (alarm.recurringDays.isEmpty()) {
                dao.setLocationAlarmEnabled(alarm.id, false)
            }
        }

        AlarmAudioController.startAlarm(
            context = applicationContext,
            vibrate = alarm.vibrate,
            headphoneModeOnly = alarm.headphoneModeOnly
        )

        val fullScreenIntent = Intent(this, AlarmRingingActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("DESTINATION_NAME", alarm.destinationName)
            putExtra("DISTANCE_METERS", currentDistanceMeters)
        }

        val fullScreenPendingIntent = PendingIntent.getActivity(
            this,
            alarm.id.toInt(),
            fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val alarmNotification = NotificationCompat.Builder(this, CHANNEL_ALARM_ALERT)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Approaching ${alarm.destinationName}")
            .setContentText("You are within $currentDistanceMeters meters of your stop!")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(NOTIFICATION_ID_ALERT, alarmNotification)
        startActivity(fullScreenIntent)
    }

    @SuppressLint("MissingPermission")
    private fun registerBackupGeofences(alarms: List<LocationAlarmEntity>) {
        val geofenceList = alarms.map { alarm ->
            Geofence.Builder()
                .setRequestId("STOPWAKE_${alarm.id}")
                .setCircularRegion(
                    alarm.latitude,
                    alarm.longitude,
                    alarm.triggerRadiusMeters.toFloat()
                )
                .setExpirationDuration(Geofence.NEVER_EXPIRE)
                .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER)
                .build()
        }

        val request = GeofencingRequest.Builder()
            .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
            .addGeofences(geofenceList)
            .build()

        geofencingClient.addGeofences(request, getGeofencePendingIntent())
    }

    private fun getGeofencePendingIntent(): PendingIntent {
        val intent = Intent(this, AlarmTriggerReceiver::class.java).apply {
            action = "ACTION_GEOFENCE_TRANSITION"
        }
        return PendingIntent.getBroadcast(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun startForegroundWithNotification(title: String, subtitle: String) {
        val notification = buildTrackingNotification(title, subtitle)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID_TRACKING,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            )
        } else {
            startForeground(NOTIFICATION_ID_TRACKING, notification)
        }
    }

    private fun updatePersistentNotification(title: String, subtitle: String) {
        notificationManager.notify(
            NOTIFICATION_ID_TRACKING,
            buildTrackingNotification(title, subtitle)
        )
    }

    private fun buildTrackingNotification(title: String, subtitle: String): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, LocationTrackingService::class.java).apply {
            action = "ACTION_STOP_TRACKING"
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_LIVE_TRACKING)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle(title)
            .setContentText(subtitle)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppIntent)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "I'm Awake / Dismiss",
                stopPendingIntent
            )
            .build()
    }

    private fun stopTrackingAndCleanup() {
        isAlarmCurrentlyRinging = false
        currentPollingTier = PollingTier.NONE
        AlarmAudioController.stopAlarm()
        ActiveTripStateHolder.clear()

        fusedLocationClient.removeLocationUpdates(locationCallback)
        geofencingClient.removeGeofences(getGeofencePendingIntent())
        notificationManager.cancel(NOTIFICATION_ID_ALERT)

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val trackingChannel = NotificationChannel(
                CHANNEL_LIVE_TRACKING,
                "Live Commute Tracking",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows live remaining distance to your destination stop"
            }

            val alertChannel = NotificationChannel(
                CHANNEL_ALARM_ALERT,
                "Destination Wake Alarms",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "High-priority wake-up alert when entering destination radius"
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }

            notificationManager.createNotificationChannel(trackingChannel)
            notificationManager.createNotificationChannel(alertChannel)
        }
    }

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_LIVE_TRACKING = "stopwake_live_tracking"
        private const val CHANNEL_ALARM_ALERT = "stopwake_alarm_alert"
        private const val NOTIFICATION_ID_TRACKING = 1001
        private const val NOTIFICATION_ID_ALERT = 1002
    }
}
