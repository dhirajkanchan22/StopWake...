package com.example.stopwake.data.local

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun fromDaysSet(days: Set<Int>): String {
        return days.sorted().joinToString(separator = ",")
    }

    @TypeConverter
    fun toDaysSet(data: String): Set<Int> {
        if (data.isBlank()) return emptySet()
        return data.split(",")
            .mapNotNull { it.trim().toIntOrNull() }
            .toSet()
    }
}
