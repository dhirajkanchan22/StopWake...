package com.example.stopwake.ui.screens

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.ScreenLockPortrait
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.accompanist.permissions.*

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun PermissionGate(
    content: @Composable () -> Unit
) {
    val context = LocalContext.current

    val foregroundPermissions = remember {
        buildList {
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
    val foregroundPermissionsState = rememberMultiplePermissionsState(foregroundPermissions)

    val backgroundPermissionState = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        rememberPermissionState(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
    } else {
        null
    }

    val hasForeground = foregroundPermissionsState.allPermissionsGranted
    val hasBackground = backgroundPermissionState?.status?.isGranted ?: true

    when {
        !hasForeground -> {
            PermissionExplanationScreen(
                icon = Icons.Default.LocationOn,
                stepLabel = "STEP 1 OF 2 • COMMUTE ACCESS",
                title = "Enable Location & Alerts",
                description = "StopWake needs precise GPS access to calculate real-time distance to your transit stop and notification access to display your live commute bar.",
                buttonText = "Grant Location & Notification Access",
                onActionClick = { foregroundPermissionsState.launchMultiplePermissionRequest() }
            )
        }

        !hasBackground -> {
            PermissionExplanationScreen(
                icon = Icons.Default.ScreenLockPortrait,
                stepLabel = "STEP 2 OF 2 • POCKET & LOCK-SCREEN MODE",
                title = "Allow Background Tracking",
                description = "When you sleep on a train or bus with your phone locked in your pocket, StopWake must monitor your stop in the background.\n\nOn the next screen, select \"Allow all the time\".",
                buttonText = "Select 'Allow All The Time'",
                onActionClick = { backgroundPermissionState?.launchPermissionRequest() }
            )
        }

        else -> {
            var fullScreenChecked by remember { mutableStateOf(canUseFullScreenIntent(context)) }

            if (!fullScreenChecked && Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                PermissionExplanationScreen(
                    icon = Icons.Default.NotificationsActive,
                    stepLabel = "FINAL CHECK • LOCK SCREEN WAKE",
                    title = "Allow Full-Screen Wake Alerts",
                    description = "To wake up your display over the lock screen when approaching your stop, enable Full-Screen Notifications for StopWake.",
                    buttonText = "Open Full-Screen Settings",
                    onActionClick = {
                        val intent = Intent(
                            Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                            Uri.parse("package:${context.packageName}")
                        )
                        context.startActivity(intent)
                        fullScreenChecked = true
                    },
                    secondaryButtonText = "Skip for now",
                    onSecondaryClick = { fullScreenChecked = true }
                )
            } else {
                content()
            }
        }
    }
}

private fun canUseFullScreenIntent(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.canUseFullScreenIntent()
    } else {
        true
    }
}

@Composable
private fun PermissionExplanationScreen(
    icon: ImageVector,
    stepLabel: String,
    title: String,
    description: String,
    buttonText: String,
    onActionClick: () -> Unit,
    secondaryButtonText: String? = null,
    onSecondaryClick: (() -> Unit)? = null
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(28.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(24.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        modifier = Modifier.size(40.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = stepLabel,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = title,
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = description,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = onActionClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    shape = MaterialTheme.shapes.medium
                ) {
                    Text(text = buttonText, style = MaterialTheme.typography.titleMedium)
                }

                if (secondaryButtonText != null && onSecondaryClick != null) {
                    TextButton(
                        onClick = onSecondaryClick,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Text(
                            text = secondaryButtonText,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
