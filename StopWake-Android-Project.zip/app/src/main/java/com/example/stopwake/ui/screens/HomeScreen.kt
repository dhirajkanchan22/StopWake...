package com.example.stopwake.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.stopwake.data.local.LocationAlarmEntity
import com.example.stopwake.data.local.TimeAlarmEntity
import com.example.stopwake.ui.theme.StatusActiveSage
import com.example.stopwake.ui.viewmodel.CommuteViewModel
import com.example.stopwake.ui.viewmodel.LiveCommuteStatus
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: CommuteViewModel,
    onNavigateToMapPicker: () -> Unit
) {
    val context = LocalContext.current
    val locationAlarms by viewModel.locationAlarms.collectAsState()
    val favoritePresets by viewModel.favoritePresets.collectAsState()
    val timeAlarms by viewModel.timeAlarms.collectAsState()
    val liveStatus by viewModel.liveCommuteStatus.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }
    var showTimeDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    if (selectedTab == 0) onNavigateToMapPicker() else showTimeDialog = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text(if (selectedTab == 0) "New Stop Alarm" else "New Clock Alarm") }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 24.dp, bottom = 100.dp)
        ) {
            item {
                Column {
                    Text(
                        text = "StopWake",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Rest easy. Wake up before your stop.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item {
                AnimatedVisibility(visible = liveStatus.isTracking) {
                    ActiveCommuteBanner(
                        status = liveStatus,
                        onDismissTrip = { viewModel.stopAllActiveTracking(context) }
                    )
                }
            }

            if (favoritePresets.isNotEmpty() && selectedTab == 0) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "DAILY PRESETS",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(favoritePresets, key = { "preset_${it.id}" }) { preset ->
                                PresetChip(
                                    alarm = preset,
                                    onActivate = {
                                        viewModel.toggleLocationAlarm(context, preset, !preset.isEnabled)
                                    }
                                )
                            }
                        }
                    }
                }
            }

            item {
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                    ) {
                        Text("Location Stops (${locationAlarms.size})")
                    }
                    SegmentedButton(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                    ) {
                        Text("Clock Alarms (${timeAlarms.size})")
                    }
                }
            }

            if (selectedTab == 0) {
                if (locationAlarms.isEmpty()) {
                    item {
                        EmptyStateCard("No location alarms yet. Tap 'New Stop Alarm' to set your destination radius.")
                    }
                } else {
                    items(locationAlarms, key = { it.id }) { alarm ->
                        LocationAlarmCard(
                            alarm = alarm,
                            onToggle = { enabled -> viewModel.toggleLocationAlarm(context, alarm, enabled) },
                            onToggleFavorite = { viewModel.toggleFavoritePreset(alarm) },
                            onDelete = { viewModel.deleteLocationAlarm(context, alarm) }
                        )
                    }
                }
            } else {
                if (timeAlarms.isEmpty()) {
                    item {
                        EmptyStateCard("No standard clock alarms set.")
                    }
                } else {
                    items(timeAlarms, key = { it.id }) { alarm ->
                        TimeAlarmCard(
                            alarm = alarm,
                            onToggle = { enabled -> viewModel.toggleTimeAlarm(context, alarm, enabled) },
                            onDelete = { viewModel.deleteTimeAlarm(context, alarm) }
                        )
                    }
                }
            }
        }
    }

    if (showTimeDialog) {
        AddTimeAlarmDialog(
            onDismiss = { showTimeDialog = false },
            onSave = { h, m, label, headphone ->
                viewModel.saveTimeAlarm(context, h, m, label, headphone)
                showTimeDialog = false
            }
        )
    }
}

@Composable
private fun ActiveCommuteBanner(
    status: LiveCommuteStatus,
    onDismissTrip: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(StatusActiveSage)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "LIVE COMMUTE TRACKING",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f)
                    )
                }
                TextButton(onClick = onDismissTrip) {
                    Text("I'm Awake / Stop", color = MaterialTheme.colorScheme.onPrimary)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = status.destinationName,
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onPrimary
            )

            val distanceText = status.distanceRemainingMeters?.let { meters ->
                if (meters >= 1000f) {
                    String.format(Locale.US, "%.1f km remaining", meters / 1000f)
                } else {
                    "${meters.toInt()} m remaining"
                }
            } ?: "Acquiring GPS lock..."

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "$distanceText • Alerts at ${status.triggerRadiusMeters}m radius",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.75f)
            )
        }
    }
}

@Composable
private fun PresetChip(
    alarm: LocationAlarmEntity,
    onActivate: () -> Unit
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = if (alarm.isEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
        modifier = Modifier.clickable { onActivate() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.NearMe,
                contentDescription = null,
                modifier = Modifier.size(16.dp),
                tint = if (alarm.isEnabled) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = alarm.title.ifBlank { alarm.destinationName },
                    style = MaterialTheme.typography.labelLarge,
                    color = if (alarm.isEnabled) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${alarm.triggerRadiusMeters}m before",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (alarm.isEnabled) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.7f)
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun LocationAlarmCard(
    alarm: LocationAlarmEntity,
    onToggle: (Boolean) -> Unit,
    onToggleFavorite: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = alarm.destinationName,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (alarm.title.isNotBlank()) {
                        Text(
                            text = alarm.title,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Switch(
                    checked = alarm.isEnabled,
                    onCheckedChange = onToggle
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Wake radius: ${
                            if (alarm.triggerRadiusMeters >= 1000) "${alarm.triggerRadiusMeters / 1000f} km"
                            else "${alarm.triggerRadiusMeters} m"
                        }",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (alarm.headphoneModeOnly) {
                        Icon(
                            imageVector = Icons.Default.Headphones,
                            contentDescription = "Headphone Mode",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row {
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            imageVector = if (alarm.isFavoritePreset) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Pin Preset",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDelete) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Delete",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TimeAlarmCard(
    alarm: TimeAlarmEntity,
    onToggle: (Boolean) -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = String.format(Locale.US, "%02d:%02d", alarm.hour, alarm.minute),
                    style = MaterialTheme.typography.displayLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = alarm.label,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = alarm.isEnabled, onCheckedChange = onToggle)
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Delete",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyStateCard(message: String) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface
    ) {
        Text(
            text = message,
            modifier = Modifier.padding(24.dp),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun AddTimeAlarmDialog(
    onDismiss: () -> Unit,
    onSave: (Int, Int, String, Boolean) -> Unit
) {
    var hourText by remember { mutableStateOf("07") }
    var minuteText by remember { mutableStateOf("30") }
    var label by remember { mutableStateOf("Morning Commute") }
    var headphoneMode by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Clock Alarm") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = hourText,
                        onValueChange = { hourText = it.take(2) },
                        label = { Text("Hour (0-23)") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = minuteText,
                        onValueChange = { minuteText = it.take(2) },
                        label = { Text("Min (0-59)") },
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("Label") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Headphone-First Mode", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = headphoneMode, onCheckedChange = { headphoneMode = it })
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val h = (hourText.toIntOrNull() ?: 7).coerceIn(0, 23)
                    val m = (minuteText.toIntOrNull() ?: 30).coerceIn(0, 59)
                    onSave(h, m, label, headphoneMode)
                }
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
