package com.example.stopwake.data.repository

import com.example.stopwake.data.local.AlarmDao
import com.example.stopwake.data.local.LocationAlarmEntity
import com.example.stopwake.data.local.TimeAlarmEntity
import kotlinx.coroutines.flow.Flow

class AlarmRepository(private val alarmDao: AlarmDao) {

    val allLocationAlarms: Flow<List<LocationAlarmEntity>> = alarmDao.observeAllLocationAlarms()
    val activeLocationAlarms: Flow<List<LocationAlarmEntity>> = alarmDao.observeActiveLocationAlarms()
    val favoritePresets: Flow<List<LocationAlarmEntity>> = alarmDao.observeFavoritePresets()
    val allTimeAlarms: Flow<List<TimeAlarmEntity>> = alarmDao.observeAllTimeAlarms()

    suspend fun getActiveLocationAlarmsSnapshot(): List<LocationAlarmEntity> {
        return alarmDao.getActiveLocationAlarmsSnapshot()
    }

    suspend fun getLocationAlarmById(id: Long): LocationAlarmEntity? {
        return alarmDao.getLocationAlarmById(id)
    }

    suspend fun saveLocationAlarm(alarm: LocationAlarmEntity): Long {
        return alarmDao.upsertLocationAlarm(alarm)
    }

    suspend fun toggleLocationAlarm(id: Long, isEnabled: Boolean) {
        alarmDao.setLocationAlarmEnabled(id, isEnabled)
    }

    suspend fun toggleFavoritePreset(id: Long, isFavorite: Boolean) {
        alarmDao.setLocationAlarmFavorite(id, isFavorite)
    }

    suspend fun deleteLocationAlarm(alarm: LocationAlarmEntity) {
        alarmDao.deleteLocationAlarm(alarm)
    }

    suspend fun getActiveTimeAlarmsSnapshot(): List<TimeAlarmEntity> {
        return alarmDao.getActiveTimeAlarmsSnapshot()
    }

    suspend fun getTimeAlarmById(id: Long): TimeAlarmEntity? {
        return alarmDao.getTimeAlarmById(id)
    }

    suspend fun saveTimeAlarm(alarm: TimeAlarmEntity): Long {
        return alarmDao.upsertTimeAlarm(alarm)
    }

    suspend fun toggleTimeAlarm(id: Long, isEnabled: Boolean) {
        alarmDao.setTimeAlarmEnabled(id, isEnabled)
    }

    suspend fun deleteTimeAlarm(alarm: TimeAlarmEntity) {
        alarmDao.deleteTimeAlarm(alarm)
    }
}
